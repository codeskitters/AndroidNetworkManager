package com.androidstudy.networkmanager;

/**
 * Created by chweya on 29/08/17.
 */

public interface LifecycleListener {
    void onStart();

    void onStop();
}
